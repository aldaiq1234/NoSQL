import { Link } from 'react-router-dom';
import { useContext } from 'react';
import AuthContext from '../context/AuthContext';
import { useCart } from '../context/CartContext'; // ✅ Импортируем useCart

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const { cart } = useCart(); // ✅ Получаем корзину

  return (
    <nav>
      <Link to="/">🏠 Home</Link>
      {user ? (
        <>
          <Link to="/profile">👤 Profile</Link>
          <Link to="/cart">🛒 Cart ({cart.length})</Link> {/* ✅ Отображаем количество товаров */}
          <button onClick={logout}>🚪 Logout</button>
        </>
      ) : (
        <Link to="/login">🔑 Login</Link>
      )}
    </nav>
  );
};

export default Navbar;
