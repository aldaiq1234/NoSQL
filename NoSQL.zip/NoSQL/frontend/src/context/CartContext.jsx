import { createContext, useContext, useState, useEffect } from "react";

// Создаем контекст корзины
const CartContext = createContext();

// ✅ Хук для использования корзины в компонентах
export const useCart = () => {
  return useContext(CartContext);
};

// ✅ Провайдер корзины
export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem("cart");
    return savedCart ? JSON.parse(savedCart) : [];
  });

  // Сохраняем корзину в localStorage при изменении
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  // ➕ Добавление товара в корзину
  const addToCart = (product) => {
    setCart((prevCart) => [...prevCart, product]);
  };

  // ❌ Очистка корзины
  const clearCart = () => {
    setCart([]);
    localStorage.removeItem("cart");
  };

  // 📦 Оформление заказа
  const placeOrder = async () => {
    const token = localStorage.getItem("token");

    if (!token) {
      alert("❌ Вы не авторизованы! Войдите в систему.");
      return;
    }

    if (cart.length === 0) {
      alert("🛒 Ваша корзина пуста!");
      return;
    }

    try {
      console.log("📡 Отправка заказа...", cart);

      // 🔥 Формируем массив товаров
      const orderItems = cart.map((item) => ({
        product: item._id, // Отправляем только ID товаров
        name: item.name,
        price: item.price,
        quantity: 1, // Можно добавить выбор количества
      }));

      // 🔥 Рассчитываем `total`
      const total = cart.reduce((sum, item) => sum + item.price, 0);

      const response = await fetch("http://localhost:3000/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ items: orderItems, total }), // ✅ Отправляем `items` и `total`
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Ошибка при создании заказа");
      }

      alert("✅ Заказ успешно оформлен!");
      clearCart(); // Очищаем корзину после заказа
      console.log("✅ Заказ создан:", data.order);
    } catch (error) {
      console.error("❌ Ошибка оформления заказа:", error);
      alert(`❌ Ошибка: ${error.message}`);
    }
  };

  return (
    <CartContext.Provider value={{ cart, addToCart, clearCart, placeOrder }}>
      {children}
    </CartContext.Provider>
  );
};
