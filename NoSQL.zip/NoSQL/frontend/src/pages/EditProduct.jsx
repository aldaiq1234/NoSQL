import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const EditProduct = () => {
  const { id: productId } = useParams(); // ✅ Получаем ID товара из URL
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [image, setImage] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [categories, setCategories] = useState([]);

  // 📌 Загружаем категории
  useEffect(() => {
    fetch('/api/categories')
      .then((res) => res.json())
      .then(setCategories)
      .catch((err) => console.error('❌ Ошибка загрузки категорий:', err));
  }, []);

  // 📌 Загружаем данные текущего товара
  useEffect(() => {
    if (!productId) return;

    fetch(`/api/products/${productId}`)
      .then((res) => res.json())
      .then((data) => {
        setName(data.name);
        setPrice(data.price);
        setImage(data.image);
        setDescription(data.description);
        setCategory(data.category?._id || '');
      })
      .catch((err) => console.error('❌ Ошибка загрузки товара:', err));
  }, [productId]);

  // 📌 Обновление товара
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token) {
      alert('❌ Ошибка: Токен отсутствует. Перезайдите в аккаунт.');
      return;
    }

    try {
      const response = await fetch(`/api/products/${productId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`, // ✅ Передаём токен
        },
        body: JSON.stringify({ name, price, image, description, category }),
      });

      const data = await response.json();

      if (response.ok) {
        alert('✅ Товар обновлен!');
        navigate('/');
      } else {
        alert(`❌ Ошибка: ${data.error}`);
      }
    } catch (error) {
      console.error('❌ Ошибка при обновлении:', error);
      alert('❌ Ошибка при обновлении товара');
    }
  };

  return (
    <div className="container">
      <h1>✏️ Редактирование товара</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Название" value={name} onChange={(e) => setName(e.target.value)} required />
        <input type="number" placeholder="Цена" value={price} onChange={(e) => setPrice(e.target.value)} required />
        <input type="text" placeholder="Ссылка на изображение" value={image} onChange={(e) => setImage(e.target.value)} required />
        <textarea placeholder="Описание" value={description} onChange={(e) => setDescription(e.target.value)} required />
        
        <select value={category} onChange={(e) => setCategory(e.target.value)} required>
          <option value="">Выберите категорию</option>
          {categories.map((cat) => (
            <option key={cat._id} value={cat._id}>{cat.name}</option>
          ))}
        </select>

        <button type="submit">💾 Сохранить изменения</button>
      </form>
    </div>
  );
};

export default EditProduct;
