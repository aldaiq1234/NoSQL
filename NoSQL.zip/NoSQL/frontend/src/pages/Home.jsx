import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getProducts } from '../api/products';
import { getCategories } from '../api/categories';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext'; // 🔥 Подключаем корзину

const Home = () => {
  const { user } = useAuth();
  const { addToCart } = useCart(); // 🔥 Используем корзину
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [categoryId, setCategoryId] = useState('');

  // Загружаем категории при старте
  useEffect(() => {
    getCategories()
      .then((data) => {
        console.log('📥 Категории загружены:', data);
        setCategories(data || []);
      })
      .catch((err) => console.error('❌ Ошибка загрузки категорий:', err));
  }, []);

  // Загружаем продукты при изменении категории
  useEffect(() => {
    getProducts(categoryId)
      .then((data) => {
        console.log('📥 Продукты загружены:', data);
        setProducts(data || []);
      })
      .catch((err) => console.error('❌ Ошибка загрузки товаров:', err));
  }, [categoryId]);

  // 📌 Удаление товара (только для админа)
  const handleDelete = async (productId) => {
    if (!window.confirm("❗ Вы уверены, что хотите удалить этот товар?")) return;

    console.log(`📡 Отправка DELETE запроса на удаление товара ID: ${productId}`);

    try {
      const response = await fetch(`http://localhost:3000/api/products/${productId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        let errorMessage = 'Ошибка при удалении товара';
        try {
          const data = await response.json();
          errorMessage = data.error || errorMessage;
        } catch (error) {
          console.error('❌ Ошибка парсинга JSON:', error);
        }
        console.error(`❌ Ошибка удаления: ${errorMessage}`);
        alert(`❌ Ошибка: ${errorMessage}`);
        return;
      }

      console.log(`✅ Товар ${productId} удалён!`);
      alert('✅ Товар удален!');
      setProducts((prevProducts) => prevProducts.filter(p => p._id !== productId));
    } catch (error) {
      console.error('❌ Ошибка при удалении:', error);
      alert('❌ Ошибка при удалении товара');
    }
  };

  return (
    <div className="container">
      <h1>🛍 Добро пожаловать в наш магазин</h1>
      <p>Выберите категорию и найдите лучший товар!</p>

      {/* 🔥 Кнопка "Добавить товар" доступна только админу */}
      {user?.role === 'admin' && (
        <button 
          onClick={() => navigate('/add-product')}
          style={{
            backgroundColor: '#4CAF50',
            color: 'white',
            padding: '10px 15px',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            marginBottom: '15px'
          }}
        >
          ➕ Добавить товар
        </button>
      )}

      {/* Фильтр по категориям */}
      <select onChange={(e) => setCategoryId(e.target.value || '')}>
        <option value="">Все категории</option>
        {categories.map((category) => (
          <option key={category._id} value={category._id}>{category.name}</option>
        ))}
      </select>

      {/* Список товаров */}
      <div className="products">
        {products.length > 0 ? (
          products.map((product) => (
            <div key={product._id} className="product" style={{
              border: '1px solid #ddd',
              padding: '15px',
              borderRadius: '8px',
              textAlign: 'center',
              marginBottom: '15px',
              width: '250px',
              boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
            }}>
              <img
                src={product.image}
                alt={product.name}
                style={{
                  width: '150px',
                  height: 'auto',
                  borderRadius: '8px',
                  marginBottom: '10px',
                }}
              />
              <h3>{product.name}</h3>
              <p>{product.description}</p>
              <strong>${product.price}</strong>
              <p>📂 Категория: {product.category?.name || 'Без категории'}</p>

              {/* 🔥 Кнопка "Добавить в корзину" */}
              <button 
                onClick={() => addToCart(product)}
                style={{
                  backgroundColor: '#FFA500',
                  color: 'white',
                  padding: '8px 12px',
                  border: 'none',
                  borderRadius: '5px',
                  cursor: 'pointer',
                  marginTop: '10px'
                }}
              >
                🛒 В корзину
              </button>

              {/* 🔥 Кнопки редактирования и удаления только для админа */}
              {user?.role === 'admin' && (
                <>
                  <button 
                    onClick={() => navigate(`/edit-product/${product._id}`)} 
                    style={{
                      margin: '5px',
                      padding: '5px 10px',
                      cursor: 'pointer',
                      backgroundColor: '#2196F3',
                      color: 'white',
                      border: 'none',
                      borderRadius: '5px'
                    }}
                  >
                    ✏️ Редактировать
                  </button>
                  <button 
                    onClick={() => handleDelete(product._id)}
                    style={{
                      margin: '5px',
                      padding: '5px 10px',
                      cursor: 'pointer',
                      backgroundColor: 'red',
                      color: 'white',
                      border: 'none',
                      borderRadius: '5px'
                    }}
                  >
                    🗑 Удалить
                  </button>
                </>
              )}
            </div>
          ))
        ) : (
          <p>📭 Нет товаров в этой категории...</p>
        )}
      </div>
    </div>
  );
};

export default Home;
