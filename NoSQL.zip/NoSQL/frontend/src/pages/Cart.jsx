
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const Cart = () => {
  const { cart, removeFromCart, clearCart, placeOrder } = useCart();
  const { user } = useAuth(); // ✅ Получаем текущего пользователя

  return (
    <div className="container">
      <h1>🛒 Ваша корзина</h1>

      {cart.length === 0 ? (
        <p>🛍 Корзина пуста...</p>
      ) : (
        <>
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {cart.map((item) => (
              <li key={item._id} style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '10px',
                borderBottom: '1px solid #ddd'
              }}>
                <img src={item.image} alt={item.name} width="50" height="50" style={{ borderRadius: '5px' }} />
                <span style={{ flex: 1, marginLeft: '10px' }}>{item.name} - ${item.price}</span>
                <button
                  onClick={() => removeFromCart(item._id)}
                  style={{
                    backgroundColor: 'red',
                    color: 'white',
                    border: 'none',
                    padding: '5px 10px',
                    cursor: 'pointer',
                    borderRadius: '5px'
                  }}>
                  ❌ Удалить
                </button>
              </li>
            ))}
          </ul>

          <div style={{ marginTop: '15px' }}>
            <button
              onClick={placeOrder}
              style={{
                backgroundColor: '#4CAF50',
                color: 'white',
                padding: '10px 15px',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer',
                fontSize: '16px'
              }}>
              ✅ Оформить заказ
            </button>

            <button
              onClick={clearCart}
              style={{
                backgroundColor: '#f44336',
                color: 'white',
                padding: '10px 15px',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer',
                fontSize: '16px',
                marginLeft: '10px'
              }}>
              🗑 Очистить корзину
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;
