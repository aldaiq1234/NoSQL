import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

const AddProduct = () => {
  const { user } = useAuth(); // ✅ Берем пользователя
  const token = localStorage.getItem('token'); // ✅ Берем токен из localStorage

  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [image, setImage] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [categories, setCategories] = useState([]);

  // Загружаем категории
  useEffect(() => {
    fetch('http://localhost:3000/api/categories') // ✅ Фиксируем URL
      .then(res => res.json())
      .then(data => setCategories(data))
      .catch(err => console.error('Ошибка загрузки категорий:', err));
  }, []);

  // Обработчик формы
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token) {
      alert('Ошибка: Вы не авторизованы!');
      return;
    }

    try {
      const response = await fetch('http://localhost:3000/api/products', { // ✅ Фиксируем URL
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` // ✅ Добавляем токен в заголовок
        },
        body: JSON.stringify({ name, price, image, description, category })
      });

      const data = await response.json();
      if (response.ok) {
        alert('✅ Товар успешно добавлен!');
        window.location.href = "/";
      } else {
        alert(`❌ Ошибка: ${data.error}`);
      }
    } catch (error) {
      console.error('Ошибка:', error);
      alert('❌ Произошла ошибка, попробуйте снова');
    }
  };

  // Если не админ — запрет доступа
  if (user?.role !== 'admin') {
    return <h2>⛔ Доступ запрещен</h2>;
  }

  return (
    <div className="container">
      <h1>➕ Добавить товар</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Название" value={name} onChange={e => setName(e.target.value)} required />
        <input type="number" placeholder="Цена" value={price} onChange={e => setPrice(e.target.value)} required />
        <input type="text" placeholder="Ссылка на изображение" value={image} onChange={e => setImage(e.target.value)} required />
        <textarea placeholder="Описание" value={description} onChange={e => setDescription(e.target.value)} required />
        
        <select value={category} onChange={e => setCategory(e.target.value)} required>
          <option value="">Выберите категорию</option>
          {categories.map(cat => (
            <option key={cat._id} value={cat._id}>{cat.name}</option>
          ))}
        </select>

        <button type="submit">Добавить</button>
      </form>
    </div>
  );
};

export default AddProduct;
