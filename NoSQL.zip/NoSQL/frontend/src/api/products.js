const API_URL = 'http://localhost:3000/api/products';

export const getProducts = async (categoryId) => {
  const url = categoryId ? `${API_URL}?category=${categoryId}` : API_URL;
  console.log('📡 Запрос API:', url);
  
  const res = await fetch(url);
  if (!res.ok) throw new Error('Ошибка загрузки товаров');
  
  return res.json();
};

export const getProductById = async (id) => {
  const res = await fetch(`${API_URL}/${id}`);
  if (!res.ok) throw new Error('Ошибка загрузки товара');
  
  return res.json();
};

export const deleteProduct = async (id, token) => {
  const res = await fetch(`${API_URL}/${id}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${token}` }
  });

  if (!res.ok) throw new Error('Ошибка удаления');
  return res.json();
};

export const updateProduct = async (id, productData, token) => {
  const res = await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(productData)
  });

  if (!res.ok) throw new Error('Ошибка обновления');
  return res.json();
};
