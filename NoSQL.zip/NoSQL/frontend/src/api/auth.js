const API_URL = 'http://localhost:3000/api/auth';

export const login = async (email, password) => {
  console.log("📤 Отправка данных на сервер:", { email, password });

  const res = await fetch(`${API_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });

  const data = await res.json();
  console.log("📥 Ответ сервера:", data);
  return data;
};


export const register = async (name, email, password) => {
  const res = await fetch(`${API_URL}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password }),
  });
  return res.json();
};

