export const getCategories = async () => {
  const response = await fetch(`http://localhost:3000/api/categories`);
  if (!response.ok) {
    throw new Error('Ошибка загрузки категорий');
  }
  return response.json();
};
