const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const ADMIN_EMAIL = 'admin@example.com'; // 🔥 Email администратора

// 📌 Регистрация нового пользователя
exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Все поля обязательны' });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'Пользователь уже существует' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    let role = 'customer'; // По умолчанию - покупатель
    if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) { // 🔥 Проверяем email админа без учёта регистра
      role = 'admin';
    }

    const newUser = new User({ name, email, password: hashedPassword, role });
    await newUser.save();

    res.status(201).json({ message: 'User created', role });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
// 📌 Логин пользователя
exports.login = async (req, res) => {
  try {
    console.log("📥 Вход в систему:", req.body);
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email и пароль обязательны' });
    }

    const user = await User.findOne({ email });
    console.log("🔍 Найденный пользователь:", user);

    if (!user) {
      return res.status(400).json({ error: 'Пользователь не найден' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    console.log("🔑 Совпадение пароля:", isMatch);

    if (!isMatch) {
      return res.status(400).json({ error: 'Неверные учетные данные' });
    }

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1d' });

    res.json({ token, user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// 📌 Выход (только на клиенте, здесь просто сообщение)
exports.logout = (req, res) => {
  res.json({ message: 'Выход выполнен' });
};

// 📌 Получение текущего пользователя (на основе токена)
exports.getMe = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1]; // Получаем токен из заголовка
    if (!token) {
      return res.status(401).json({ error: 'Нет токена, доступ запрещен' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-password'); // Убираем пароль из ответа

    if (!user) {
      return res.status(404).json({ error: 'Пользователь не найден' });
    }

    res.json(user);
  } catch (error) {
    res.status(401).json({ error: 'Ошибка аутентификации' });
  }
};
