const express = require('express');
const Category = require('../models/Category');
const router = express.Router();

// 📌 Получить все категории
router.get('/', async (req, res) => {
  try {
    const categories = await Category.find();
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 📌 Добавить новую категорию (только для админа)
router.post('/', async (req, res) => {
  try {
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Название категории обязательно' });
    }

    const newCategory = new Category({ name });
    await newCategory.save();
    
    res.status(201).json(newCategory);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;

