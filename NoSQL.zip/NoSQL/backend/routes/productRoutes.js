const express = require('express');
const mongoose = require('mongoose');
const Product = require('../models/Product');
const Category = require('../models/Category');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const router = express.Router();

// 📌 Middleware: Проверка роли "admin"
const verifyAdmin = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Нет токена, доступ запрещен' });
    }

    const token = authHeader.split(' ')[1]; // ✅ Берём сам токен
    if (!token) {
      return res.status(401).json({ error: 'Токен отсутствует' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (!decoded || !decoded.id) {
      return res.status(401).json({ error: 'Ошибка декодирования токена' });
    }

    const user = await User.findById(decoded.id);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: 'Доступ запрещен' });
    }

    req.user = user;
    next();
  } catch (error) {
    console.error('❌ Ошибка аутентификации:', error);
    res.status(401).json({ error: 'Ошибка аутентификации, повторите вход' });
  }
};

// 📌 Получить все товары
router.get('/', async (req, res) => {
  try {
    console.log('📡 GET /api/products запрос');

    let filter = {};
    if (req.query.category) {
      if (!mongoose.Types.ObjectId.isValid(req.query.category)) {
        return res.status(400).json({ error: 'Некорректный ID категории' });
      }
      filter.category = new mongoose.Types.ObjectId(req.query.category);
    }

    const products = await Product.find(filter).populate('category', 'name');
    res.json(products);
  } catch (error) {
    console.error('❌ Ошибка сервера:', error);
    res.status(500).json({ error: error.message });
  }
});

// 📌 Получить один товар по ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔍 Получение товара ID: ${id}`);

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'Некорректный ID товара' });
    }

    const product = await Product.findById(id).populate('category', 'name');
    if (!product) {
      return res.status(404).json({ error: 'Товар не найден' });
    }

    res.json(product);
  } catch (error) {
    console.error('❌ Ошибка сервера:', error);
    res.status(500).json({ error: error.message });
  }
});

// 📌 Добавить новый товар (только для админа)
router.post('/', verifyAdmin, async (req, res) => {
  try {
    console.log('📡 POST /api/products запрос');

    const { name, price, image, description, category } = req.body;

    if (!name || !price || !image || !description || !category) {
      return res.status(400).json({ error: 'Все поля обязательны' });
    }

    if (!mongoose.Types.ObjectId.isValid(category)) {
      return res.status(400).json({ error: 'Некорректный ID категории' });
    }

    const categoryExists = await Category.findById(category);
    if (!categoryExists) {
      return res.status(400).json({ error: 'Категория не найдена' });
    }

    const newProduct = new Product({ name, price, image, description, category });
    await newProduct.save();

    console.log('✅ Новый товар добавлен:', newProduct);
    res.status(201).json(newProduct);
  } catch (error) {
    console.error('❌ Ошибка сервера:', error);
    res.status(500).json({ error: error.message });
  }
});

// 📌 Обновить товар по ID (только для админа)
router.put('/:id', verifyAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`📝 Обновление товара ID: ${id}`);

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'Некорректный ID товара' });
    }

    const { name, price, image, description, category } = req.body;

    if (category && !mongoose.Types.ObjectId.isValid(category)) {
      return res.status(400).json({ error: 'Некорректный ID категории' });
    }

    if (category) {
      const categoryExists = await Category.findById(category);
      if (!categoryExists) {
        return res.status(400).json({ error: 'Категория не найдена' });
      }
    }

    const updatedProduct = await Product.findByIdAndUpdate(
      id,
      { name, price, image, description, category },
      { new: true, runValidators: true }
    );

    if (!updatedProduct) {
      return res.status(404).json({ error: 'Товар не найден' });
    }

    console.log(`✅ Товар ${id} обновлён`);
    res.json({ message: '✅ Товар обновлен', updatedProduct });
  } catch (error) {
    console.error('❌ Ошибка сервера:', error);
    res.status(500).json({ error: error.message });
  }
});

// 📌 Удалить товар по ID (только для админа)
router.delete('/:id', verifyAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🗑 Удаление товара ID: ${id}`);

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'Некорректный ID товара' });
    }

    const product = await Product.findById(id);
    if (!product) {
      return res.status(404).json({ error: '❌ Товар не найден' });
    }

    await Product.findByIdAndDelete(id);
    console.log(`✅ Товар ${id} удалён`);
    res.json({ message: '✅ Товар удалён' });

  } catch (error) {
    console.error('❌ Ошибка сервера:', error);
    res.status(500).json({ error: error.message });
  }
});

export default router;

