const express = require('express');
const Order = require('../models/Order');
const User = require('../models/User');
const jwt = require('jsonwebtoken');

const router = express.Router();

// 📌 Middleware: Проверка авторизации пользователя
const verifyUser = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ error: 'Нет токена, доступ запрещен' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);

    if (!user) {
      return res.status(403).json({ error: 'Пользователь не найден' });
    }

    req.user = user;
    next();
  } catch (error) {
    console.error('Ошибка аутентификации:', error);
    res.status(401).json({ error: 'Ошибка аутентификации' });
  }
};

// 📌 Создать заказ
router.post('/', verifyUser, async (req, res) => {
    try {
      const { items, total } = req.body;
      console.log('📥 Заказ получен:', items);
  
      if (!items || items.length === 0) {
        return res.status(400).json({ error: 'Корзина пуста' });
      }
  
      const order = new Order({
        user: req.user._id,
        items: items,  // ✅ Проверяем, что массив товаров передаётся
        total,
        status: 'pending'
      });
  
      await order.save();
      console.log('✅ Заказ сохранён в базе:', order);
      res.status(201).json({ message: '✅ Заказ создан', order });
    } catch (error) {
      console.error('❌ Ошибка при создании заказа:', error);
      res.status(500).json({ error: 'Ошибка сервера' });
    }
  });
  export default router;
