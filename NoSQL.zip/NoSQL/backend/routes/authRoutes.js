const express = require('express');
const { register, login, logout, getMe } = require('../controllers/authController');
const router = express.Router();

router.post('/register', register); // 📌 Регистрация
router.post('/login', login); // 📌 Логин
router.post('/logout', logout); // 📌 Выход
router.get('/me', getMe); // 📌 Получение текущего пользователя

export default router;

